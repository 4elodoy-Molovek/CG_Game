﻿using System.Collections.Generic;
using OpenTK.Mathematics;

public class Physics
{
    private List<Ball> balls;
    private float friction = 0.98f; // simple friction factor per frame
    private float tableWidth = 1.5f; // example values, adjust to your table
    private float tableHeight = 3.0f;

    public Physics(List<(Vector3 position, Vector3 color)> ballData)
    {
        balls = new List<Ball>();

        foreach (var (position, color) in ballData)
        {
            balls.Add(new Ball
            {
                Position = position,
                Velocity = Vector3.Zero,
                Color = color
            });
        }
    }

    public List<Ball> GetBalls()
    {
        return balls;
    }

    public void Update(float deltaTime)
    {
        foreach (var ball in balls)
        {
            ball.Position += ball.Velocity * deltaTime;

            // Apply friction
            ball.Velocity *= friction;

            // Bounce off table walls
            if (System.Math.Abs(ball.Position.X) > tableWidth / 2)
            {
                ball.Position.X = System.Math.Sign(ball.Position.X) * tableWidth / 2;
                ball.Velocity.X *= -1;
            }
            if (System.Math.Abs(ball.Position.Z) > tableHeight / 2)
            {
                ball.Position.Z = System.Math.Sign(ball.Position.Z) * tableHeight / 2;
                ball.Velocity.Z *= -1;
            }

            // Small velocity cutoff (stop when very slow)
            if (ball.Velocity.LengthSquared < 0.0001f)
            {
                ball.Velocity = Vector3.Zero;
            }
        }
    }

    public void StrikeCueBall(Vector3 direction, float force)
    {
        // Strike the first ball (assuming it's the cue ball)
        if (balls.Count > 0)
        {
            balls[0].Velocity = Vector3.Normalize(new Vector3(direction.X, 0, direction.Z)) * force;
        }
    }

    public class Ball
    {
        public Vector3 Position;
        public Vector3 Velocity;
        public Vector3 Color;
    }
}
